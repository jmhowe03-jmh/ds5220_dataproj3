from chalice import Chalice, Rate
import boto3
import time
import requests
import pandas as pd
import matplotlib.pyplot as plt
import io
import os

app = Chalice(app_name='weather-system')

# Configuration - Change these to match your setup!
S3_BUCKET = "your-bucket-name-here"
TABLE_NAME = "SyracuseWeather"
LAT, LON = 43.0481, -76.1474

@app.schedule(Rate(1, unit=Rate.HOURS))
def ingest_weather(event):
    """Part 1: Ingest Syracuse weather data every hour."""
    url = f"https://api.open-meteo.com/v1/forecast?latitude={LAT}&longitude={LON}&current_weather=true&temperature_unit=fahrenheit"
    
    try:
        r = requests.get(url, timeout=10)
        r.raise_for_status()
        current = r.json()['current_weather']
        
        table = boto3.resource('dynamodb').Table(TABLE_NAME)
        item = {
            'city': 'Syracuse',
            'timestamp': int(time.time()),
            'temp': float(current['temperature']),
            'wind': float(current['windspeed'])
        }
        table.put_item(Item=item)
    except Exception as e:
        print(f"Ingest failed: {e}")


@app.route('/latest')
def latest():
    """Resource 1: Get the most recent weather record."""
    table = boto3.resource('dynamodb').Table(TABLE_NAME)
    response = table.query(
        KeyConditionExpression=boto3.query.Key('city').eq('Syracuse'),
        ScanIndexForward=False, Limit=1
    )
    return response.get('Items', [{}])[0]

@app.route('/stats')
def stats():
    """Resource 2: Simple summary stats."""
    table = boto3.resource('dynamodb').Table(TABLE_NAME)
    items = table.query(KeyConditionExpression=boto3.query.Key('city').eq('Syracuse'))['Items']
    if not items: return {"error": "No data yet"}
    
    temps = [float(i['temp']) for i in items]
    return {
        "avg_temp": sum(temps) / len(temps),
        "count": len(items)
    }

@app.route('/chart')
def chart():
    """Resource 3: Generate plot and return S3 URL."""
    table = boto3.resource('dynamodb').Table(TABLE_NAME)
    items = table.query(KeyConditionExpression=boto3.query.Key('city').eq('Syracuse'))['Items']
    
    # 1. Plotting
    df = pd.DataFrame(items)
    df['time'] = pd.to_datetime(df['timestamp'], unit='s')
    plt.figure(figsize=(6, 4))
    plt.plot(df['time'], df['temp'], color='blue', label='Temp (F)')
    plt.title("Syracuse Temperature")
    
    # 2. Upload to S3
    img_data = io.BytesIO()
    plt.savefig(img_data, format='png')
    img_data.seek(0)
    
    s3 = boto3.client('s3')
    key = "plot.png"
    s3.put_object(Bucket=S3_BUCKET, Key=key, Body=img_data, 
                  ContentType='image/png', ACL='public-read')
    
    return {"image_url": f"https://{S3_BUCKET}.s3.amazonaws.com/{key}"}