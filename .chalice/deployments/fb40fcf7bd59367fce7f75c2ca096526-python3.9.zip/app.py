"""
app.py — DS5220 Data Project 3
Syracuse, NY hourly weather tracker.

Part 1: @app.schedule  → ingests weather from Open-Meteo → DynamoDB + S3 plot
Part 2: @app.route     → exposes /  /current  /trend  /plot  via API Gateway

Environment variables (set in .chalice/config.json):
    S3_BUCKET   — name of the S3 bucket for plot images  (e.g. "dp3-weather-jh")
    TABLE_NAME  — DynamoDB table name                     (default: weather-data)
    AWS_REGION  — AWS region                              (default: us-east-1)

Lambda layers supply the heavy libraries (pandas, matplotlib, numpy):
    arn:aws:lambda:us-east-1:336392948345:layer:AWSSDKPandas-Python39:13
    arn:aws:lambda:us-east-1:770693421928:layer:Klayers-p39-matplotlib:1
requirements.txt only needs: requests
"""

import io
import logging
import os
import time
from datetime import datetime, timezone

import boto3
import matplotlib
matplotlib.use("Agg")          # non-interactive backend — required in Lambda
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import requests
from boto3.dynamodb.conditions import Key
from chalice import Chalice, Rate

# ---------------------------------------------------------------------------
# Logging — CloudWatch picks this up automatically
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Chalice app
# ---------------------------------------------------------------------------
app = Chalice(app_name="weather-system")

# ---------------------------------------------------------------------------
# Config — driven by Lambda environment variables (set in .chalice/config.json)
# ---------------------------------------------------------------------------
S3_BUCKET  = os.environ.get("S3_BUCKET",  "dp3-weather-plots-vxx4kn")   # ← UPDATE before deploying
TABLE_NAME = os.environ.get("TABLE_NAME", "weather-data")
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

LAT      = 43.0481        # Syracuse, NY
LON      = -76.1474
CITY     = "Syracuse"
PLOT_KEY = "weather/syracuse-latest.png"   # fixed key → stable public URL


# ===========================================================================
# PART 1 — Scheduled ingestion  (fires every hour via EventBridge)
# ===========================================================================

@app.schedule(Rate(1, unit=Rate.HOURS))
def ingest_weather(event):
    """
    Fetch current weather from Open-Meteo (free, no API key needed) and
    write a timestamped record to DynamoDB. Then rebuild the plot and push
    it to S3 at a fixed key so /plot always returns a fresh image URL.
    """
    log.info("ingest_weather triggered | lat=%.4f lon=%.4f", LAT, LON)

    # --- 1. Fetch from Open-Meteo ----------------------------------------
    url = (
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={LAT}&longitude={LON}"
        "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code"
        "&temperature_unit=fahrenheit"
        "&wind_speed_unit=mph"
        "&timezone=auto"
    )
    try:
        log.info("Calling Open-Meteo API")
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        data    = resp.json()
        current = data["current"]
        log.info(
            "Open-Meteo OK | temp=%.2f°F | humidity=%.1f%% | wind=%.1f mph | wmo=%s",
            current["temperature_2m"],
            current["relative_humidity_2m"],
            current["wind_speed_10m"],
            current.get("weather_code"),
        )
    except requests.RequestException as exc:
        log.exception("Open-Meteo fetch failed: %s", exc)
        return {"statusCode": 500, "error": str(exc)}

    # --- 2. Build DynamoDB item -------------------------------------------
    ts   = int(time.time())
    item = {
        "city":      CITY,
        "timestamp": ts,                                                   # sort key (Number)
        "temp_f":    round(float(current["temperature_2m"]),       2),
        "humidity":  round(float(current["relative_humidity_2m"]), 1),
        "wind_mph":  round(float(current["wind_speed_10m"]),       1),
        "wmo_code":  int(current.get("weather_code", 0)),
        "utc_time":  datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    log.info("DynamoDB item: %s", item)

    # --- 3. Write to DynamoDB --------------------------------------------
    try:
        dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
        table    = dynamodb.Table(TABLE_NAME)
        table.put_item(Item=item)
        log.info("DynamoDB write OK | location_id=%s | timestamp=%d", CITY, ts)
    except Exception as exc:
        log.exception("DynamoDB write failed: %s", exc)
        return {"statusCode": 500, "error": str(exc)}

    # --- 4. Fetch history and regenerate plot ----------------------------
    # Plot failure must NOT crash the ingestion — log and continue
    try:
        history = _query_all(table)
        if len(history) >= 2:
            plot_buf = _generate_plot(history)
            if plot_buf:
                _upload_plot(plot_buf)
        else:
            log.info("Not enough history to plot yet (%d record(s))", len(history))
    except Exception as exc:
        log.exception("Plot generation/upload failed (non-fatal): %s", exc)

    log.info("ingest_weather complete | timestamp=%d", ts)
    return {
        "statusCode": 200,
        "city":       CITY,
        "timestamp":  ts,
        "temp_f":     item["temp_f"],
        "humidity":   item["humidity"],
        "wind_mph":   item["wind_mph"],
    }


# ===========================================================================
# Shared helpers
# ===========================================================================

def _get_table():
    """Return a boto3 DynamoDB Table resource."""
    try:
        dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
        return dynamodb.Table(TABLE_NAME)
    except Exception as exc:
        log.exception("Failed to connect to DynamoDB: %s", exc)
        raise


def _query_all(table) -> list:
    """
    Return ALL records for CITY, sorted oldest-first.
    Handles DynamoDB pagination so the full history is returned
    regardless of table size.
    """
    log.info("Querying DynamoDB | city=%s", CITY)
    try:
        items  = []
        kwargs = dict(
            KeyConditionExpression=Key("city").eq(CITY),
            ScanIndexForward=True,
        )
        page = 0
        while True:
            resp  = table.query(**kwargs)
            batch = resp.get("Items", [])
            items.extend(batch)
            page += 1
            log.info("DynamoDB page %d: %d records (total=%d)", page, len(batch), len(items))
            if "LastEvaluatedKey" not in resp:
                break
            kwargs["ExclusiveStartKey"] = resp["LastEvaluatedKey"]

        log.info("DynamoDB query complete | total records=%d", len(items))
        return items
    except Exception as exc:
        log.exception("DynamoDB query failed: %s", exc)
        return []


def _generate_plot(items: list):
    """
    Build a dual-axis temperature + humidity line chart from DynamoDB records.
    Returns a PNG BytesIO buffer, or None if there's not enough data.
    """
    if len(items) < 2:
        log.info("Skipping plot — only %d record(s) available", len(items))
        return None

    log.info("Generating plot for %d data points", len(items))
    try:
        df = pd.DataFrame(items)
        df["datetime"] = pd.to_datetime(df["timestamp"], unit="s", utc=True)
        df["temp_f"]   = df["temp_f"].astype(float)
        df["humidity"] = df["humidity"].astype(float)
        df = df.sort_values("datetime").reset_index(drop=True)

        fig, ax1 = plt.subplots(figsize=(12, 5))
        ax2 = ax1.twinx()

        # Temperature (°F) — left axis, orange
        ax1.plot(df["datetime"], df["temp_f"],   color="#FF6B35", linewidth=2.5,
                 label="Temp (°F)", zorder=2)
        ax1.fill_between(df["datetime"], df["temp_f"], df["temp_f"].min() - 1,
                         alpha=0.10, color="#FF6B35")

        # Humidity (%) — right axis, blue dashed
        ax2.plot(df["datetime"], df["humidity"], color="#4FC3F7", linewidth=2.0,
                 linestyle="--", label="Humidity (%)", zorder=2)

        # Labels + formatting
        last_ts = df["datetime"].max().strftime("%Y-%m-%d %H:%M UTC")
        ax1.set_title(
            f"Syracuse, NY — Weather History\nLast updated: {last_ts}",
            fontsize=13, fontweight="bold", pad=10,
        )
        ax1.set_xlabel("Time (UTC)", labelpad=6)
        ax1.set_ylabel("Temperature (°F)", color="#FF6B35", labelpad=6)
        ax2.set_ylabel("Relative Humidity (%)", color="#4FC3F7", labelpad=6)
        ax1.tick_params(axis="y", labelcolor="#FF6B35")
        ax2.tick_params(axis="y", labelcolor="#4FC3F7")
        ax2.set_ylim(0, 110)
        ax1.xaxis.set_major_formatter(mdates.DateFormatter("%m/%d %H:%M"))
        fig.autofmt_xdate(rotation=25, ha="right")

        # Combined legend
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2,
                   loc="upper left", fontsize=9, framealpha=0.85)
        if ax2.get_legend():
            ax2.get_legend().remove()

        plt.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
        buf.seek(0)
        plt.close(fig)
        log.info("Plot generated | size=%d bytes", len(buf.getvalue()))
        return buf

    except Exception as exc:
        log.exception("Plot generation failed: %s", exc)
        plt.close("all")
        return None


def _upload_plot(buf: io.BytesIO) -> str:
    """
    Upload a PNG buffer to S3 at a fixed key and return the public URL.
    The bucket must have a public-read bucket policy (see DEPLOY.md).
    """
    log.info("Uploading plot to s3://%s/%s", S3_BUCKET, PLOT_KEY)
    try:
        s3 = boto3.client("s3", region_name=AWS_REGION)
        s3.put_object(
            Bucket=S3_BUCKET,
            Key=PLOT_KEY,
            Body=buf.getvalue(),
            ContentType="image/png",
        )
        url = f"https://{S3_BUCKET}.s3.{AWS_REGION}.amazonaws.com/{PLOT_KEY}"
        log.info("Plot uploaded | url=%s", url)
        return url
    except Exception as exc:
        log.exception("S3 upload failed: %s", exc)
        raise


# ===========================================================================
# PART 2 — Chalice API routes
# ===========================================================================

@app.route("/")
def index():
    """
    Zone apex — required by the course Discord bot.
    Returns project description and list of callable resources.
    """
    log.info("GET /")
    return {
        "about": (
            "Tracks hourly weather in Syracuse, NY — temperature, humidity, and wind — "
            "using the Open-Meteo API. Data stored in DynamoDB; plot regenerated each hour in S3."
        ),
        "resources": ["current", "trend", "plot"],
    }


@app.route("/current")
def current():
    """Return the most recent weather reading as a human-readable string."""
    log.info("GET /current")
    try:
        table = _get_table()
        resp  = table.query(
            KeyConditionExpression=Key("location_id").eq(CITY),
            ScanIndexForward=False,
            Limit=1,
        )
        items = resp.get("Items", [])

        if not items:
            log.warning("GET /current — no data in DynamoDB yet")
            return {"response": "No data collected yet — the ingestion Lambda hasn't run. Check back soon!"}

        item = items[0]
        ts   = datetime.fromtimestamp(int(item["timestamp"]), tz=timezone.utc)
        msg  = (
            f"Syracuse, NY ({ts.strftime('%Y-%m-%d %H:%M UTC')}): "
            f"{float(item['temp_f']):.1f}°F | "
            f"Humidity {float(item['humidity']):.0f}% | "
            f"Wind {float(item['wind_mph']):.1f} mph"
        )
        log.info("GET /current → %s", msg)
        return {"response": msg}

    except Exception as exc:
        log.exception("GET /current failed: %s", exc)
        return {"response": f"Error fetching current weather: {exc}"}


@app.route("/trend")
def trend():
    """
    Return a trend summary: averages, min/max temp, and a warming/cooling
    direction computed by comparing the oldest vs newest 3 readings.
    """
    log.info("GET /trend")
    try:
        table = _get_table()
        items = _query_all(table)

        if not items:
            return {"response": "No data collected yet — check back after the first ingestion run."}

        temps  = [float(i["temp_f"])   for i in items]
        humids = [float(i["humidity"]) for i in items]
        n      = len(items)

        avg_t = sum(temps)  / n
        avg_h = sum(humids) / n
        min_t = min(temps)
        max_t = max(temps)

        # Trend direction: compare first-3 vs last-3 averages
        if n >= 6:
            early  = sum(temps[:3])  / 3
            recent = sum(temps[-3:]) / 3
            delta  = recent - early
            if   delta >  1.5:  direction = f"warming (+{delta:.1f}°F)"
            elif delta < -1.5:  direction = f"cooling ({delta:.1f}°F)"
            else:               direction = "stable"
            trend_str = f" Recent trend: {direction} over {n} readings."
        else:
            trend_str = f" ({n} reading(s) so far — more data needed for trend.)"

        msg = (
            f"Syracuse weather over {n} hourly readings: "
            f"avg {avg_t:.1f}°F (range {min_t:.1f}–{max_t:.1f}°F), "
            f"avg humidity {avg_h:.0f}%.{trend_str}"
        )
        log.info("GET /trend → %s", msg)
        return {"response": msg}

    except Exception as exc:
        log.exception("GET /trend failed: %s", exc)
        return {"response": f"Error computing trend: {exc}"}


@app.route("/plot")
def plot():
    """
    Return the public S3 URL of the latest weather chart PNG.
    The image is regenerated every hour by the ingest_weather Lambda.
    """
    log.info("GET /plot")
    url = f"https://{S3_BUCKET}.s3.{AWS_REGION}.amazonaws.com/{PLOT_KEY}"
    log.info("GET /plot → %s", url)
    return {"response": url}
